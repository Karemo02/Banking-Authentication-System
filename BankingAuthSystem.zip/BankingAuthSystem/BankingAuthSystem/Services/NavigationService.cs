﻿using BankingAuthSystem.Views;
using System.Windows.Controls;

namespace BankingAuthSystem.Services
{
    public class NavigationService
    {
        private readonly MainWindow _mainWindow;
        private readonly ApiClient _apiClient;

        public NavigationService(MainWindow mainWindow, ApiClient apiClient)
        {
            _mainWindow = mainWindow;
            _apiClient = apiClient;
        }

        public void NavigateToLogin()
        {
            _mainWindow.MainContent.Content = new LoginView(_apiClient, this);
        }

        public void NavigateToCreateAccount()
        {
            _mainWindow.MainContent.Content = new CreateAccountView(_apiClient, this);
        }

        public void NavigateToOtpVerification(string username)
        {
            _mainWindow.MainContent.Content = new OtpVerificationView(_apiClient, this, username);
        }

        public void NavigateToDashboard()
        {
            _mainWindow.MainContent.Content = new DashboardView(_apiClient, this);
        }

        public void NavigateToTransfer()
        {
            _mainWindow.MainContent.Content = new TransferView(_apiClient, this);
        }
    }
}