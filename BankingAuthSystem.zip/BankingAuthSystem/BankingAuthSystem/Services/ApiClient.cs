﻿using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using BankingAuthSystem.Models;

namespace BankingAuthSystem.Services
{
    public class ApiClient
    {
        private readonly HttpClient _httpClient;
        private string _token;

        public ApiClient()
        {
            _httpClient = new HttpClient
            {
                BaseAddress = new Uri("https://localhost:7226/api/")
            };
        }

        // Constructor for testing
        public ApiClient(HttpClient httpClient)
        {
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        }

        public async Task<string> LoginAsync(string username, string password)
        {
            var request = new { username, password };
            var content = new StringContent(JsonSerializer.Serialize(request), Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync("auth/login", content);
            var responseString = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                return responseString;
            }
            else
            {
                try
                {
                    var error = JsonSerializer.Deserialize<ErrorResponse>(responseString);
                    throw new Exception(error.ErrorMessage ?? "Unknown error during login");
                }
                catch (JsonException ex)
                {
                    throw new Exception($"Login failed: {responseString}");
                }
            }
        }

        public async Task<string> VerifyOtpAsync(string username, string otp)
        {
            var request = new { username, otp };
            var content = new StringContent(JsonSerializer.Serialize(request), Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync("auth/verify-otp", content);
            var responseString = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                var result = JsonSerializer.Deserialize<VerifyOtpResponse>(responseString);
                return result.Token;
            }
            else
            {
                try
                {
                    var error = JsonSerializer.Deserialize<ErrorResponse>(responseString);
                    throw new Exception(error.ErrorMessage ?? "Unknown error during OTP verification");
                }
                catch (JsonException ex)
                {
                    throw new Exception($"OTP verification failed: {responseString}");
                }
            }
        }

        public void SetToken(string token)
        {
            _token = token;
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }

        public string GetToken()
        {
            return _token;
        }

        public async Task<DashboardData> GetDashboardAsync()
        {
            if (string.IsNullOrEmpty(_token))
            {
                throw new Exception("No token set");
            }

            var response = await _httpClient.GetAsync("user/dashboard");
            var json = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                return JsonSerializer.Deserialize<DashboardData>(json);
            }
            else
            {
                try
                {
                    var error = JsonSerializer.Deserialize<ErrorResponse>(json);
                    throw new Exception(error.ErrorMessage ?? "Unknown error loading dashboard");
                }
                catch (JsonException ex)
                {
                    throw new Exception($"Failed to load dashboard: {json}");
                }
            }
        }

        public async Task<TransferResponse> MakeTransferAsync(string receiverUsername, decimal amount, string description)
        {
            if (string.IsNullOrEmpty(_token))
            {
                throw new Exception("No token set");
            }

            var request = new TransferRequest
            {
                ReceiverUsername = receiverUsername,
                Amount = amount,
                Description = description
            };
            var content = new StringContent(JsonSerializer.Serialize(request), Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync("user/transfer", content);
            var responseString = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                try
                {
                    var error = JsonSerializer.Deserialize<ErrorResponse>(responseString);
                    throw new Exception(error.ErrorMessage ?? "Unknown error during transfer");
                }
                catch (JsonException ex)
                {
                    throw new Exception($"Transfer failed: {responseString}");
                }
            }

            var transferResponse = JsonSerializer.Deserialize<TransferResponse>(responseString);
            return transferResponse;
        }

        public async Task<CreateAccountResponse> CreateAccountAsync(string username, string email, string password, string trustedCountries)
        {
            var request = new
            {
                username,
                email,
                password,
                trustedCountries
            };
            var content = new StringContent(JsonSerializer.Serialize(request), Encoding.UTF8, "application/json");
            HttpResponseMessage response;
            string responseString;

            try
            {
                response = await _httpClient.PostAsync("Auth/register", content);
                responseString = await response.Content.ReadAsStringAsync();
            }
            catch (HttpRequestException ex)
            {
                throw new Exception($"Network error: Unable to reach the server. Is the server running at https://localhost:7226?");
            }

            if (response.IsSuccessStatusCode)
            {
                try
                {
                    if (responseString.Trim().StartsWith("{") && responseString.Trim().EndsWith("}"))
                    {
                        var createResponse = JsonSerializer.Deserialize<CreateAccountResponse>(responseString);
                        return createResponse;
                    }
                    else
                    {
                        return new CreateAccountResponse { Message = responseString };
                    }
                }
                catch (JsonException ex)
                {
                    throw new Exception($"Failed to deserialize success response: {responseString}");
                }
            }
            else
            {
                try
                {
                    var error = JsonSerializer.Deserialize<ErrorResponse>(responseString);
                    throw new Exception(error.ErrorMessage ?? "Unknown error during account creation");
                }
                catch (JsonException)
                {
                    try
                    {
                        var validationError = JsonSerializer.Deserialize<ValidationErrorResponse>(responseString);
                        if (validationError.Errors != null && validationError.Errors.Count > 0)
                        {
                            var errorMessages = string.Join("; ", validationError.Errors.SelectMany(e => e.Value));
                            throw new Exception($"Validation error: {errorMessages}");
                        }
                        throw new Exception("Unknown error during account creation");
                    }
                    catch (JsonException ex)
                    {
                        throw new Exception($"Account creation failed with status {response.StatusCode}: {responseString}");
                    }
                }
            }
        }
    }

    public class ValidationErrorResponse
    {
        public string Type { get; set; }
        public string Title { get; set; }
        public int Status { get; set; }
        public string TraceId { get; set; }
        public Dictionary<string, string[]> Errors { get; set; }
    }
}