﻿using System.Windows;

namespace BankingAuthSystem
{
    public partial class App : Application
    {
    }
}