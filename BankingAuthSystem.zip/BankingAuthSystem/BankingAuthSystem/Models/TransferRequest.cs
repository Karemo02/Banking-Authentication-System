﻿namespace BankingAuthSystem.Models
{
    public class TransferRequest
    {
        public string ReceiverUsername { get; set; }
        public decimal Amount { get; set; }
        public string Description { get; set; }
    }
}