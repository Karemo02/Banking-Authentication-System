﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace BankingAuthSystem.Models
{
    public class DashboardData
    {
        [JsonPropertyName("username")]
        public string Username { get; set; }

        [JsonPropertyName("accountBalance")]
        public decimal AccountBalance { get; set; }

        [JsonPropertyName("trustedCountries")]
        public string TrustedCountries { get; set; }

        [JsonPropertyName("recentTransactions")]
        public List<Transaction> RecentTransactions { get; set; }
    }

    public class Transaction
    {
        [JsonPropertyName("transactionId")]
        public int TransactionId { get; set; }

        [JsonPropertyName("senderUsername")]
        public string SenderUsername { get; set; }

        [JsonPropertyName("receiverUsername")]
        public string ReceiverUsername { get; set; }

        [JsonPropertyName("amount")]
        public decimal Amount { get; set; }

        [JsonPropertyName("transactionDate")]
        public DateTime TransactionDate { get; set; }

        [JsonPropertyName("description")]
        public string Description { get; set; }
    }
}