﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace BankingAuthSystem.Models
{
    public class LoginResponse
    {
        public string Message { get; set; }
    }

    public class VerifyOtpResponse
    {
        [JsonPropertyName("token")]
        public string Token { get; set; }
    }

    public class TransferResponse
    {
        [JsonPropertyName("message")]
        public string Message { get; set; }

        [JsonPropertyName("fraudWarnings")]
        public List<string> FraudWarnings { get; set; }
    }

    public class CreateAccountResponse
    {
        [JsonPropertyName("message")]
        public string Message { get; set; }
    }

    public class ErrorResponse
    {
        public string ErrorMessage { get; set; }
    }
}