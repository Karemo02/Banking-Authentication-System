﻿using BankingAuthSystem.Services;
using BankingAuthSystem.Views;
using System.Windows;

namespace BankingAuthSystem
{
    public partial class MainWindow : Window
    {
        private readonly NavigationService _navigationService;
        private readonly ApiClient _apiClient;

        public MainWindow()
        {
            InitializeComponent();
            _apiClient = new ApiClient();
            _navigationService = new NavigationService(this, _apiClient);
            _navigationService.NavigateToLogin();
        }
    }
}