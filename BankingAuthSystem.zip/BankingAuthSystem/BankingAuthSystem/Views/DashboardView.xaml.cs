﻿using BankingAuthSystem.Services;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace BankingAuthSystem.Views
{
    public partial class DashboardView : UserControl
    {
        private readonly ApiClient _apiClient;
        private readonly NavigationService _navigationService;

        public DashboardView(ApiClient apiClient, NavigationService navigationService)
        {
            InitializeComponent();
            _apiClient = apiClient;
            _navigationService = navigationService;
            LoadDashboard();
        }

        private async void LoadDashboard()
        {
            try
            {
                var dashboardData = await _apiClient.GetDashboardAsync();
                UsernameTextBlock.Text = $"Welcome, {dashboardData.Username}";
                BalanceTextBlock.Text = $"Balance: £{dashboardData.AccountBalance:F2}";
                TrustedCountriesTextBlock.Text = $"Trusted Countries: {dashboardData.TrustedCountries}";
                TransactionsDataGrid.ItemsSource = dashboardData.RecentTransactions ?? new System.Collections.Generic.List<BankingAuthSystem.Models.Transaction>();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading dashboard: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void TransferButton_Click(object sender, RoutedEventArgs e)
        {
            _navigationService.NavigateToTransfer();
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            // Clear the token
            _apiClient.SetToken(null);
            // Navigate back to the login page
            _navigationService.NavigateToLogin();
        }
    }
}