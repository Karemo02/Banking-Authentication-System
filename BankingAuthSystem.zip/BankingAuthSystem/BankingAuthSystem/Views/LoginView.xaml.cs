﻿using BankingAuthSystem.Services;
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace BankingAuthSystem.Views
{
    public partial class LoginView : UserControl
    {
        private readonly ApiClient _apiClient;
        private readonly NavigationService _navigationService;

        public LoginView(ApiClient apiClient, NavigationService navigationService)
        {
            InitializeComponent();
            _apiClient = apiClient;
            _navigationService = navigationService;
        }

        private async void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            var username = UsernameTextBox.Text;
            var password = PasswordBox.Password;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                ResultTextBlock.Text = "Please enter both username and password.";
                ResultTextBlock.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D32F2F"));
                return;
            }

            try
            {
                var response = await _apiClient.LoginAsync(username, password);
                ResultTextBlock.Text = "Login successful. Please enter the OTP sent to your email.";
                ResultTextBlock.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#4CAF50"));

                _navigationService.NavigateToOtpVerification(username);
            }
            catch (Exception ex)
            {
                ResultTextBlock.Text = ex.Message;
                ResultTextBlock.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D32F2F"));
            }
        }

        private void CreateAccountButton_Click(object sender, RoutedEventArgs e)
        {
            _navigationService.NavigateToCreateAccount();
        }
    }
}