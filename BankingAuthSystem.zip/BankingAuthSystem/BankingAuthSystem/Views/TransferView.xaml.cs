﻿using BankingAuthSystem.Services;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace BankingAuthSystem.Views
{
    public partial class TransferView : UserControl
    {
        private readonly ApiClient _apiClient;
        private readonly NavigationService _navigationService;

        public TransferView(ApiClient apiClient, NavigationService navigationService)
        {
            InitializeComponent();
            _apiClient = apiClient;
            _navigationService = navigationService;
        }

        private async void SubmitTransferButton_Click(object sender, RoutedEventArgs e)
        {
            if (!decimal.TryParse(AmountTextBox.Text, out var amount) || string.IsNullOrWhiteSpace(ReceiverTextBox.Text))
            {
                ResultTextBlock.Text = "Please enter a valid amount and receiver username.";
                ResultTextBlock.Foreground = new SolidColorBrush(Colors.Red);
                return;
            }

            var receiverUsername = ReceiverTextBox.Text;
            var description = DescriptionTextBox.Text;

            try
            {
                var response = await _apiClient.MakeTransferAsync(receiverUsername, amount, description);
                var message = response.Message;
                if (response.FraudWarnings != null && response.FraudWarnings.Count > 0)
                {
                    message += "\nWarnings: " + string.Join(", ", response.FraudWarnings);
                }

                ResultTextBlock.Text = message;
                ResultTextBlock.Foreground = new SolidColorBrush(Colors.Green);

                await System.Threading.Tasks.Task.Delay(5000); // Changed from 2000 to 5000 (5 seconds)
                _navigationService.NavigateToDashboard();
            }
            catch (Exception ex)
            {
                ResultTextBlock.Text = ex.Message;
                ResultTextBlock.Foreground = new SolidColorBrush(Colors.Red);
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            _navigationService.NavigateToDashboard();
        }
    }
}