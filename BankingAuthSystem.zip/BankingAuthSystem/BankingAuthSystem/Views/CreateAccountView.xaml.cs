﻿using BankingAuthSystem.Services;
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace BankingAuthSystem.Views
{
    public partial class CreateAccountView : UserControl
    {
        private readonly ApiClient _apiClient;
        private readonly NavigationService _navigationService;

        public CreateAccountView(ApiClient apiClient, NavigationService navigationService)
        {
            InitializeComponent();
            _apiClient = apiClient;
            _navigationService = navigationService;
        }

        private async void CreateAccountButton_Click(object sender, RoutedEventArgs e)
        {
            var username = UsernameTextBox.Text;
            var email = EmailTextBox.Text;
            var password = PasswordBox.Password;
            var trustedCountries = TrustedCountriesTextBox.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(trustedCountries))
            {
                ResultTextBlock.Text = "All fields are required.";
                ResultTextBlock.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D32F2F"));
                return;
            }

            System.Diagnostics.Debug.WriteLine($"Creating account: Username={username}, Email={email}, TrustedCountries={trustedCountries}");

            try
            {
                var response = await _apiClient.CreateAccountAsync(username, email, password, trustedCountries);

                ResultTextBlock.Text = response.Message;
                ResultTextBlock.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#4CAF50"));

                await Task.Delay(2000);
                _navigationService.NavigateToLogin();
            }
            catch (Exception ex)
            {
                ResultTextBlock.Text = ex.Message;
                ResultTextBlock.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D32F2F"));
                System.Diagnostics.Debug.WriteLine($"Create Account Error: {ex.Message}");
            }
        }
    }
}