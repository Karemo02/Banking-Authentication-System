﻿using BankingAuthSystem.Services;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace BankingAuthSystem.Views
{
    public partial class OtpVerificationView : UserControl
    {
        private readonly ApiClient _apiClient;
        private readonly NavigationService _navigationService;
        private readonly string _username;

        public OtpVerificationView(ApiClient apiClient, NavigationService navigationService, string username)
        {
            InitializeComponent();
            _apiClient = apiClient;
            _navigationService = navigationService;
            _username = username;
        }

        private async void VerifyOtpButton_Click(object sender, RoutedEventArgs e)
        {
            var otp = OtpTextBox.Text;

            if (string.IsNullOrWhiteSpace(otp))
            {
                ResultTextBlock.Text = "Please enter the OTP.";
                ResultTextBlock.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D32F2F"));
                return;
            }

            try
            {
                var token = await _apiClient.VerifyOtpAsync(_username, otp);
                _apiClient.SetToken(token);

                ResultTextBlock.Text = "OTP verified successfully.";
                ResultTextBlock.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#4CAF50"));

                _navigationService.NavigateToDashboard();
            }
            catch (Exception ex)
            {
                ResultTextBlock.Text = ex.Message;
                ResultTextBlock.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D32F2F"));
            }
        }

        private void BackToLoginButton_Click(object sender, RoutedEventArgs e)
        {
            _navigationService.NavigateToLogin();
        }
    }
}