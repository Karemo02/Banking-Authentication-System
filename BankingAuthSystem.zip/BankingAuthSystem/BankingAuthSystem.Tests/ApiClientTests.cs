﻿using NUnit.Framework;
using BankingAuthSystem.Services;
using System.Threading.Tasks;
using Moq;
using System.Net.Http;
using System.Net;
using System.Text;
using System.IO;
using System;
using System.Threading;
using Moq.Protected;

namespace BankingAuthSystem.Tests
{
    [TestFixture]
    public class ApiClientTests
    {
        private ApiClient _apiClient;
        private Mock<HttpMessageHandler> _httpMessageHandlerMock;
        private HttpClient _httpClient;

        [SetUp]
        public void Setup()
        {
            _httpMessageHandlerMock = new Mock<HttpMessageHandler>();

            _httpClient = new HttpClient(_httpMessageHandlerMock.Object)
            {
                BaseAddress = new Uri("https://localhost:7226/api/")
            };

            _apiClient = new ApiClient(_httpClient);

            // Create a test trusted_ips.txt
            File.WriteAllText("trusted_ips.txt", "127.0.0.1");
        }

        [TearDown]
        public void TearDown()
        {
            _httpClient?.Dispose();
            _httpMessageHandlerMock = null;
            _apiClient = null;

            if (File.Exists("trusted_ips.txt"))
            {
                File.Delete("trusted_ips.txt");
            }
        }

        [Test]
        public async Task LoginAsync_WithInvalidCredentials_ThrowsException()
        {
            // Arrange
            string invalidUsername = "nonexistentuser";
            string invalidPassword = "wrongpassword";

            _httpMessageHandlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.Unauthorized,
                    Content = new StringContent("Invalid username or password", Encoding.UTF8, "application/json")
                });

            // Act & Assert
            var exception = Assert.ThrowsAsync<Exception>(async () =>
            {
                await _apiClient.LoginAsync(invalidUsername, invalidPassword);
            }, "Expected an exception for invalid login credentials.");

            Assert.That(exception.Message, Does.Contain("Invalid username or password"),
                "Exception message should indicate login failure.");
        }

        [Test]
        public async Task LoginAsync_WithMultipleFailedAttemptsFromDifferentIps_ThrowsLockoutException()
        {
            // Arrange
            string username = "logan";
            string invalidPassword = "wrongpassword";

            // Simulate 3 failed attempts from different IPs
            string[] ipAddresses = { "192.168.1.1", "192.168.1.2", "192.168.1.3" };

            for (int i = 0; i < 3; i++)
            {
                File.WriteAllText("trusted_ips.txt", ipAddresses[i]);

                _httpMessageHandlerMock.Protected()
                    .Setup<Task<HttpResponseMessage>>(
                        "SendAsync",
                        ItExpr.IsAny<HttpRequestMessage>(),
                        ItExpr.IsAny<CancellationToken>())
                    .ReturnsAsync(new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Unauthorized,
                        Content = new StringContent(
                            i < 2
                                ? "Invalid username or password"
                                : "Account locked due to multiple failed login attempts from different IPs. Please contact an admin.",
                            Encoding.UTF8,
                            "application/json")
                    });

                // Act & Assert
                var exception = Assert.ThrowsAsync<Exception>(async () =>
                {
                    await _apiClient.LoginAsync(username, invalidPassword);
                }, $"Expected failure for attempt {i + 1}");

                if (i < 2)
                {
                    Assert.That(exception.Message, Does.Contain("Invalid username or password"));
                }
                else
                {
                    Assert.That(exception.Message, Does.Contain("Account locked"));
                }
            }
        }
    }
}
