﻿using BankingAuthSystem.Server.Models;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO; // Add for file reading
using System.Security.Cryptography;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http; // Add for IHttpContextAccessor

namespace BankingAuthSystem.Server.Services
{
    public class DatabaseService
    {
        private readonly string _connectionString;
        private readonly IHttpContextAccessor _httpContextAccessor; // Add to access request IP
        private readonly string _ipConfigPath; // Path to trusted_ips.txt

        public DatabaseService(IConfiguration configuration, IHttpContextAccessor httpContextAccessor, string ipConfigPath = "trusted_ips.txt")
        {
            _connectionString = configuration.GetConnectionString("MySql");
            _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
            _ipConfigPath = ipConfigPath ?? throw new ArgumentNullException(nameof(ipConfigPath));
        }

        public async Task<bool> TestConnectionAsync()
        {
            try
            {
                System.Console.WriteLine($"Testing connection: {_connectionString}");
                using var connection = new MySqlConnection(_connectionString);
                await connection.OpenAsync();
                System.Console.WriteLine("Connection successful");
                return true;
            }
            catch (MySqlException ex)
            {
                System.Console.WriteLine($"Database connection failed: {ex.Message}");
                return false;
            }
        }

        public async Task<bool> RegisterUserAsync(User user)
        {
            try
            {
                using var connection = new MySqlConnection(_connectionString);
                await connection.OpenAsync();

                // Check if username exists
                var checkCmd = new MySqlCommand("SELECT COUNT(*) FROM Users WHERE Username = @Username", connection);
                checkCmd.Parameters.AddWithValue("@Username", user.Username);
                var count = Convert.ToInt32(await checkCmd.ExecuteScalarAsync());
                if (count > 0)
                {
                    System.Console.WriteLine($"Registration failed: Username {user.Username} already exists");
                    return false; // Username already exists
                }

                // Hash password with PBKDF2
                byte[] salt = RandomNumberGenerator.GetBytes(16); // 16-byte salt
                using var pbkdf2 = new Rfc2898DeriveBytes(user.Password, salt, 100000, HashAlgorithmName.SHA256);
                byte[] hash = pbkdf2.GetBytes(32); // 32-byte hash
                byte[] hashBytes = new byte[48]; // Salt (16) + Hash (32)
                Array.Copy(salt, 0, hashBytes, 0, 16);
                Array.Copy(hash, 0, hashBytes, 16, 32);
                string hashedPassword = Convert.ToBase64String(hashBytes);

                // Insert user
                var insertCmd = new MySqlCommand(
                    "INSERT INTO Users (Username, HashedPassword, Email, TrustedCountries, AccountBalance) " +
                    "VALUES (@Username, @HashedPassword, @Email, @TrustedCountries, @AccountBalance)",
                    connection);
                insertCmd.Parameters.AddWithValue("@Username", user.Username);
                insertCmd.Parameters.AddWithValue("@HashedPassword", hashedPassword);
                insertCmd.Parameters.AddWithValue("@Email", user.Email);
                insertCmd.Parameters.AddWithValue("@TrustedCountries", user.TrustedCountries);
                insertCmd.Parameters.AddWithValue("@AccountBalance", 1000.00);

                await insertCmd.ExecuteNonQueryAsync();
                System.Console.WriteLine($"User {user.Username} registered successfully");
                return true;
            }
            catch (MySqlException ex)
            {
                System.Console.WriteLine($"Registration failed: {ex.Message}");
                return false;
            }
        }

        public async Task<(bool Success, string Username)> LoginUserAsync(string username, string password)
        {
            try
            {
                System.Console.WriteLine($"Attempting login for username: {username}");
                using var connection = new MySqlConnection(_connectionString);
                await connection.OpenAsync();

                // Retrieve user
                var selectCmd = new MySqlCommand(
                    "SELECT Username, HashedPassword, LoginAttempts, LastLoginAttempt FROM Users WHERE Username = @Username",
                    connection);
                selectCmd.Parameters.AddWithValue("@Username", username);
                using var reader = await selectCmd.ExecuteReaderAsync();

                if (!await reader.ReadAsync())
                {
                    System.Console.WriteLine($"User {username} not found");
                    await reader.CloseAsync();
                    await LogFailedAttemptAsync(username, connection, false);
                    return (false, null);
                }

                string storedHash = reader.GetString("HashedPassword");
                int loginAttempts = reader.GetInt32("LoginAttempts");
                DateTime? lastLoginAttempt = reader.IsDBNull(reader.GetOrdinal("LastLoginAttempt"))
                    ? null
                    : reader.GetDateTime("LastLoginAttempt");
                System.Console.WriteLine($"User {username} found, LoginAttempts: {loginAttempts}, LastLoginAttempt: {lastLoginAttempt}");
                await reader.CloseAsync();

                // Check login attempts and auto-unlock if 15 minutes have passed (existing logic)
                if (loginAttempts >= 5)
                {
                    if (lastLoginAttempt.HasValue && (DateTime.Now - lastLoginAttempt.Value).TotalMinutes >= 15)
                    {
                        System.Console.WriteLine($"Auto-unlocking account {username}: 15 minutes elapsed");
                        await ResetLoginAttemptsAsync(username, connection);
                        loginAttempts = 0;
                    }
                    else
                    {
                        System.Console.WriteLine($"Account {username} is locked (LoginAttempts >= 5)");
                        await UpdateLoginAttemptsAsync(username, connection, false);
                        return (false, null); // Account locked
                    }
                }

                // Check IP-based lockout using FraudLog
                var fraudCmd = new MySqlCommand(
                    "SELECT COUNT(DISTINCT IpAddress) as UniqueIpCount, MAX(IsLocked) as IsLocked " +
                    "FROM FraudLog WHERE Username = @Username AND AttemptTime > @TimeThreshold",
                    connection);
                fraudCmd.Parameters.AddWithValue("@Username", username);
                fraudCmd.Parameters.AddWithValue("@TimeThreshold", DateTime.Now.AddMinutes(-15)); // 15-minute window
                using var fraudReader = await fraudCmd.ExecuteReaderAsync();
                int uniqueIpCount = 0;
                bool isIpLocked = false;
                if (await fraudReader.ReadAsync())
                {
                    uniqueIpCount = fraudReader.GetInt32("UniqueIpCount");
                    isIpLocked = !fraudReader.IsDBNull(1) && fraudReader.GetBoolean("IsLocked");
                }
                await fraudReader.CloseAsync();

                if (isIpLocked)
                {
                    System.Console.WriteLine($"Account {username} is locked due to multiple failed login attempts from different IPs");
                    await LogFailedAttemptAsync(username, connection, false);
                    return (false, null);
                }

                // Verify password
                byte[] hashBytes = Convert.FromBase64String(storedHash);
                byte[] salt = new byte[16];
                Array.Copy(hashBytes, 0, salt, 0, 16);
                using var pbkdf2 = new Rfc2898DeriveBytes(password, salt, 100000, HashAlgorithmName.SHA256);
                byte[] hash = pbkdf2.GetBytes(32);
                bool passwordMatch = true;
                for (int i = 0; i < 32; i++)
                {
                    if (hashBytes[i + 16] != hash[i])
                    {
                        passwordMatch = false;
                        break;
                    }
                }

                System.Console.WriteLine($"Password match for {username}: {passwordMatch}");
                await LogFailedAttemptAsync(username, connection, passwordMatch);

                // Update login attempts and last login attempt (existing logic)
                await UpdateLoginAttemptsAsync(username, connection, passwordMatch);

                // Check for IP lockout condition after logging the attempt
                if (!passwordMatch)
                {
                    fraudCmd = new MySqlCommand(
                        "SELECT COUNT(DISTINCT IpAddress) as UniqueIpCount FROM FraudLog " +
                        "WHERE Username = @Username AND AttemptTime > @TimeThreshold",
                        connection);
                    fraudCmd.Parameters.AddWithValue("@Username", username);
                    fraudCmd.Parameters.AddWithValue("@TimeThreshold", DateTime.Now.AddMinutes(-15));
                    using var fraudReader2 = await fraudCmd.ExecuteReaderAsync();
                    if (await fraudReader2.ReadAsync())
                    {
                        uniqueIpCount = fraudReader2.GetInt32("UniqueIpCount");
                    }
                    await fraudReader2.CloseAsync();

                    if (uniqueIpCount >= 3)
                    {
                        var lockCmd = new MySqlCommand(
                            "UPDATE FraudLog SET IsLocked = TRUE WHERE Username = @Username AND AttemptTime > @TimeThreshold",
                            connection);
                        lockCmd.Parameters.AddWithValue("@Username", username);
                        lockCmd.Parameters.AddWithValue("@TimeThreshold", DateTime.Now.AddMinutes(-15));
                        await lockCmd.ExecuteNonQueryAsync();

                        System.Console.WriteLine($"Account {username} locked due to multiple failed login attempts from different IPs");
                        return (false, null);
                    }
                }
                else
                {
                    // Clear FraudLog on successful login
                    var clearCmd = new MySqlCommand(
                        "DELETE FROM FraudLog WHERE Username = @Username",
                        connection);
                    clearCmd.Parameters.AddWithValue("@Username", username);
                    await clearCmd.ExecuteNonQueryAsync();
                }

                return (passwordMatch, passwordMatch ? username : null);
            }
            catch (MySqlException ex)
            {
                System.Console.WriteLine($"Login failed: {ex.Message}");
                return (false, null);
            }
        }

        private async Task LogFailedAttemptAsync(string username, MySqlConnection connection, bool success)
        {
            if (success) return; // Only log failed attempts

            string ipAddress = GetIpAddress();
            var fraudCmd = new MySqlCommand(
                "INSERT INTO FraudLog (Username, IpAddress, AttemptTime, IsLocked) " +
                "VALUES (@Username, @IpAddress, @AttemptTime, @IsLocked)",
                connection);
            fraudCmd.Parameters.AddWithValue("@Username", username);
            fraudCmd.Parameters.AddWithValue("@IpAddress", ipAddress);
            fraudCmd.Parameters.AddWithValue("@AttemptTime", DateTime.Now);
            fraudCmd.Parameters.AddWithValue("@IsLocked", false);
            await fraudCmd.ExecuteNonQueryAsync();

            System.Console.WriteLine($"Logged failed login attempt for {username} from IP {ipAddress}");
        }

        private string GetIpAddress()
        {
            // Read IP from text file for testing, fallback to request IP
            try
            {
                if (File.Exists(_ipConfigPath))
                {
                    var ip = File.ReadAllText(_ipConfigPath).Trim();
                    System.Console.WriteLine($"Using IP from trusted_ips.txt: {ip}");
                    return ip;
                }
            }
            catch (Exception ex)
            {
                System.Console.WriteLine($"Failed to read IP from trusted_ips.txt: {ex.Message}");
            }
            var requestIp = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString() ?? "unknown";
            System.Console.WriteLine($"Using request IP: {requestIp}");
            return requestIp;
        }

        public async Task<string> GenerateAndStoreOtpAsync(string username)
        {
            try
            {
                using var connection = new MySqlConnection(_connectionString);
                await connection.OpenAsync();

                // Generate 6-digit OTP
                string otp = RandomNumberGenerator.GetInt32(100000, 999999).ToString("D6");
                DateTime expiry = DateTime.Now.AddMinutes(5); // BST

                // Store OTP and expiry
                var updateCmd = new MySqlCommand(
                    "UPDATE Users SET OtpCode = @OtpCode, OtpExpiry = @OtpExpiry WHERE Username = @Username",
                    connection);
                updateCmd.Parameters.AddWithValue("@Username", username);
                updateCmd.Parameters.AddWithValue("@OtpCode", otp);
                updateCmd.Parameters.AddWithValue("@OtpExpiry", expiry);
                await updateCmd.ExecuteNonQueryAsync();

                System.Console.WriteLine($"OTP generated for {username}: {otp}, expires at {expiry:yyyy-MM-dd HH:mm:ss} (BST)");
                return otp;
            }
            catch (MySqlException ex)
            {
                System.Console.WriteLine($"OTP generation failed: {ex.Message}");
                return null;
            }
        }

        public async Task<bool> VerifyOtpAsync(string username, string otp)
        {
            try
            {
                using var connection = new MySqlConnection(_connectionString);
                await connection.OpenAsync();

                // Retrieve OTP and expiry
                var selectCmd = new MySqlCommand(
                    "SELECT OtpCode, OtpExpiry FROM Users WHERE Username = @Username",
                    connection);
                selectCmd.Parameters.AddWithValue("@Username", username);
                using var reader = await selectCmd.ExecuteReaderAsync();

                if (!await reader.ReadAsync())
                {
                    System.Console.WriteLine($"User {username} not found for OTP verification");
                    return false;
                }

                string storedOtp = reader.IsDBNull(reader.GetOrdinal("OtpCode"))
                    ? null
                    : reader.GetString("OtpCode");
                DateTime? expiry = reader.IsDBNull(reader.GetOrdinal("OtpExpiry"))
                    ? null
                    : reader.GetDateTime("OtpExpiry");
                await reader.CloseAsync();

                if (storedOtp == null || expiry == null)
                {
                    System.Console.WriteLine($"No valid OTP found for {username}");
                    return false;
                }

                if (DateTime.Now > expiry)
                {
                    System.Console.WriteLine($"OTP for {username} has expired");
                    return false;
                }

                bool isValid = storedOtp == otp;
                System.Console.WriteLine($"OTP verification for {username}: {isValid}");

                if (isValid)
                {
                    // Clear OTP after successful verification
                    var clearCmd = new MySqlCommand(
                        "UPDATE Users SET OtpCode = NULL, OtpExpiry = NULL WHERE Username = @Username",
                        connection);
                    clearCmd.Parameters.AddWithValue("@Username", username);
                    await clearCmd.ExecuteNonQueryAsync();
                }

                return isValid;
            }
            catch (MySqlException ex)
            {
                System.Console.WriteLine($"OTP verification failed: {ex.Message}");
                return false;
            }
        }

        public async Task<DashboardData> GetDashboardDataAsync(string username)
        {
            try
            {
                using var connection = new MySqlConnection(_connectionString);
                await connection.OpenAsync();

                // Fetch user details
                var userCmd = new MySqlCommand(
                    "SELECT Username, AccountBalance, TrustedCountries FROM Users WHERE Username = @Username",
                    connection);
                userCmd.Parameters.AddWithValue("@Username", username);
                using var userReader = await userCmd.ExecuteReaderAsync();

                if (!await userReader.ReadAsync())
                {
                    System.Console.WriteLine($"User {username} not found for dashboard");
                    return null;
                }

                var dashboardData = new DashboardData
                {
                    Username = userReader.GetString("Username"),
                    AccountBalance = userReader.GetDecimal("AccountBalance"),
                    TrustedCountries = userReader.GetString("TrustedCountries"),
                    RecentTransactions = new List<Transaction>()
                };
                await userReader.CloseAsync();

                // Fetch recent transactions (last 5)
                var transCmd = new MySqlCommand(
                    "SELECT TransactionId, SenderUsername, ReceiverUsername, Amount, TransactionDate, Description " +
                    "FROM Transactions " +
                    "WHERE SenderUsername = @Username OR ReceiverUsername = @Username " +
                    "ORDER BY TransactionDate DESC LIMIT 5",
                    connection);
                transCmd.Parameters.AddWithValue("@Username", username);
                using var transReader = await transCmd.ExecuteReaderAsync();

                while (await transReader.ReadAsync())
                {
                    dashboardData.RecentTransactions.Add(new Transaction
                    {
                        TransactionId = transReader.GetInt32("TransactionId"),
                        SenderUsername = transReader.GetString("SenderUsername"),
                        ReceiverUsername = transReader.GetString("ReceiverUsername"),
                        Amount = transReader.GetDecimal("Amount"),
                        TransactionDate = transReader.GetDateTime("TransactionDate"),
                        Description = transReader.IsDBNull(transReader.GetOrdinal("Description"))
                            ? null
                            : transReader.GetString("Description")
                    });
                }

                System.Console.WriteLine($"Dashboard data retrieved for {username}");
                return dashboardData;
            }
            catch (MySqlException ex)
            {
                System.Console.WriteLine($"Dashboard data retrieval failed: {ex.Message}");
                return null;
            }
        }

        public async Task<(bool Success, string ErrorMessage, List<string> FraudWarnings)> TransferMoneyAsync(string senderUsername, string receiverUsername, decimal amount, string description)
        {
            try
            {
                using var connection = new MySqlConnection(_connectionString);
                await connection.OpenAsync();

                // Start transaction
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Check if sender and receiver exist and get balances and countries
                    var checkCmd = new MySqlCommand(
                        "SELECT Username, AccountBalance, TrustedCountries FROM Users WHERE Username IN (@Sender, @Receiver) FOR UPDATE",
                        connection, transaction);
                    checkCmd.Parameters.AddWithValue("@Sender", senderUsername);
                    checkCmd.Parameters.AddWithValue("@Receiver", receiverUsername);
                    using var reader = await checkCmd.ExecuteReaderAsync();

                    decimal? senderBalance = null;
                    string senderCountries = null, receiverCountries = null;
                    bool senderFound = false, receiverFound = false;

                    while (await reader.ReadAsync())
                    {
                        string username = reader.GetString("Username");
                        if (username == senderUsername)
                        {
                            senderBalance = reader.GetDecimal("AccountBalance");
                            senderCountries = reader.GetString("TrustedCountries");
                            senderFound = true;
                        }
                        else if (username == receiverUsername)
                        {
                            receiverCountries = reader.GetString("TrustedCountries");
                            receiverFound = true;
                        }
                    }
                    await reader.CloseAsync();

                    if (!senderFound)
                        return (false, "Sender not found", null);
                    if (!receiverFound)
                        return (false, "Receiver not found", null);
                    if (senderUsername == receiverUsername)
                        return (false, "Cannot transfer to yourself", null);
                    if (amount <= 0)
                        return (false, "Amount must be positive", null);
                    if (amount > 10000)
                        return (false, "Amount exceeds maximum transfer limit (£10,000)", null);
                    if (senderBalance < amount)
                        return (false, "Insufficient funds", null);

                    // Fraud detection
                    List<string> fraudWarnings = new List<string>();
                    if (amount > 5000)
                    {
                        fraudWarnings.Add("Large transfer amount (£5,000 or more)");
                    }

                    // Check trusted countries
                    var senderCountryList = senderCountries?.Split(',').Select(c => c.Trim()).ToList() ?? new List<string>();
                    var receiverCountryList = receiverCountries?.Split(',').Select(c => c.Trim()).ToList() ?? new List<string>();
                    bool isTrusted = receiverCountryList.Any(rc => senderCountryList.Contains(rc));
                    if (!isTrusted && receiverCountryList.Any())
                    {
                        fraudWarnings.Add($"Receiver's countries ({receiverCountries}) not in sender's trusted countries ({senderCountries})");
                    }

                    // Update sender's balance
                    var updateSenderCmd = new MySqlCommand(
                        "UPDATE Users SET AccountBalance = AccountBalance - @Amount WHERE Username = @Username",
                        connection, transaction);
                    updateSenderCmd.Parameters.AddWithValue("@Amount", amount);
                    updateSenderCmd.Parameters.AddWithValue("@Username", senderUsername);
                    await updateSenderCmd.ExecuteNonQueryAsync();

                    // Update receiver's balance
                    var updateReceiverCmd = new MySqlCommand(
                        "UPDATE Users SET AccountBalance = AccountBalance + @Amount WHERE Username = @Username",
                        connection, transaction);
                    updateReceiverCmd.Parameters.AddWithValue("@Amount", amount);
                    updateReceiverCmd.Parameters.AddWithValue("@Username", receiverUsername);
                    await updateReceiverCmd.ExecuteNonQueryAsync();

                    // Log transaction
                    var insertTransCmd = new MySqlCommand(
                        "INSERT INTO Transactions (SenderUsername, ReceiverUsername, Amount, TransactionDate, Description) " +
                        "VALUES (@Sender, @Receiver, @Amount, @Date, @Description); " +
                        "SELECT LAST_INSERT_ID();",
                        connection, transaction);
                    insertTransCmd.Parameters.AddWithValue("@Sender", senderUsername);
                    insertTransCmd.Parameters.AddWithValue("@Receiver", receiverUsername);
                    insertTransCmd.Parameters.AddWithValue("@Amount", amount);
                    insertTransCmd.Parameters.AddWithValue("@Date", DateTime.Now); // BST
                    insertTransCmd.Parameters.AddWithValue("@Description", string.IsNullOrEmpty(description) ? DBNull.Value : description);
                    var transactionId = Convert.ToInt32(await insertTransCmd.ExecuteScalarAsync());

                    // Log fraud alerts if any
                    if (fraudWarnings.Any())
                    {
                        foreach (var warning in fraudWarnings)
                        {
                            var fraudCmd = new MySqlCommand(
                                "INSERT INTO FraudAlerts (TransactionId, Reason, AlertDate) " +
                                "VALUES (@TransactionId, @Reason, @AlertDate)",
                                connection, transaction);
                            fraudCmd.Parameters.AddWithValue("@TransactionId", transactionId);
                            fraudCmd.Parameters.AddWithValue("@Reason", warning);
                            fraudCmd.Parameters.AddWithValue("@AlertDate", DateTime.Now); // BST
                            await fraudCmd.ExecuteNonQueryAsync();
                        }
                    }

                    // Commit transaction
                    await transaction.CommitAsync();
                    System.Console.WriteLine($"Transfer successful: {senderUsername} sent {amount} to {receiverUsername}" +
                        (fraudWarnings.Any() ? $"; Fraud warnings: {string.Join(", ", fraudWarnings)}" : ""));
                    return (true, null, fraudWarnings);
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    System.Console.WriteLine($"Transfer failed: {ex.Message}");
                    return (false, "Transfer failed due to an error", null);
                }
            }
            catch (MySqlException ex)
            {
                System.Console.WriteLine($"Transfer failed: {ex.Message}");
                return (false, "Transfer failed due to a database error", null);
            }
        }

        private async Task UpdateLoginAttemptsAsync(string username, MySqlConnection connection, bool success)
        {
            int loginAttempts = success ? 0 : 1;

            if (!success)
            {
                var countCmd = new MySqlCommand(
                    "SELECT LoginAttempts FROM Users WHERE Username = @Username",
                    connection);
                countCmd.Parameters.AddWithValue("@Username", username);
                var result = await countCmd.ExecuteScalarAsync();
                loginAttempts = result != null ? Convert.ToInt32(result) + 1 : 1;
            }

            var updateCmd = new MySqlCommand(
                "UPDATE Users SET LoginAttempts = @LoginAttempts, LastLoginAttempt = @LastLoginAttempt " +
                "WHERE Username = @Username",
                connection);
            updateCmd.Parameters.AddWithValue("@Username", username);
            updateCmd.Parameters.AddWithValue("@LoginAttempts", loginAttempts);
            updateCmd.Parameters.AddWithValue("@LastLoginAttempt", DateTime.Now); // BST

            await updateCmd.ExecuteNonQueryAsync();
            System.Console.WriteLine($"Updated {username}: LoginAttempts={loginAttempts}, LastLoginAttempt={DateTime.Now:yyyy-MM-dd HH:mm:ss} (BST)");
        }

        private async Task ResetLoginAttemptsAsync(string username, MySqlConnection connection)
        {
            var resetCmd = new MySqlCommand(
                "UPDATE Users SET LoginAttempts = 0, LastLoginAttempt = NULL WHERE Username = @Username",
                connection);
            resetCmd.Parameters.AddWithValue("@Username", username);
            await resetCmd.ExecuteNonQueryAsync();
            System.Console.WriteLine($"Reset LoginAttempts for {username} to 0");
        }
    }

    public class DashboardData
    {
        public string Username { get; set; }
        public decimal AccountBalance { get; set; }
        public string TrustedCountries { get; set; }
        public List<Transaction> RecentTransactions { get; set; }
    }

    public class Transaction
    {
        public int TransactionId { get; set; }
        public string SenderUsername { get; set; }
        public string ReceiverUsername { get; set; }
        public decimal Amount { get; set; }
        public DateTime TransactionDate { get; set; }
        public string Description { get; set; }
    }
}