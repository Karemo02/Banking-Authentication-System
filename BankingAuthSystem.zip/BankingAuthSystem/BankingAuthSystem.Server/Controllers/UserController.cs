﻿using BankingAuthSystem.Server.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Security.Claims;

namespace BankingAuthSystem.Server.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly DatabaseService _databaseService;

        public UserController(DatabaseService databaseService)
        {
            _databaseService = databaseService;
        }

        [HttpGet("dashboard")]
        public async Task<IActionResult> GetDashboard()
        {
            // Get username from JWT
            var username = User.FindFirst(ClaimTypes.Name)?.Value;
            if (string.IsNullOrEmpty(username))
            {
                return Unauthorized("Invalid token");
            }

            var dashboardData = await _databaseService.GetDashboardDataAsync(username);
            if (dashboardData == null)
            {
                return NotFound("User not found");
            }

            return Ok(dashboardData);
        }

        [HttpPost("transfer")]
        public async Task<IActionResult> Transfer([FromBody] TransferRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.ReceiverUsername) || request.Amount <= 0)
            {
                return BadRequest("Receiver username and positive amount are required");
            }

            // Get sender from JWT
            var senderUsername = User.FindFirst(ClaimTypes.Name)?.Value;
            if (string.IsNullOrEmpty(senderUsername))
            {
                return Unauthorized("Invalid token");
            }

            var (success, errorMessage, fraudWarnings) = await _databaseService.TransferMoneyAsync(
                senderUsername,
                request.ReceiverUsername,
                request.Amount,
                request.Description);

            if (success)
            {
                var response = new
                {
                    Message = "Transfer successful",
                    FraudWarnings = fraudWarnings ?? new List<string>()
                };
                return Ok(response);
            }
            else
            {
                return BadRequest(errorMessage);
            }
        }
    }

    public class TransferRequest
    {
        public string ReceiverUsername { get; set; }
        public decimal Amount { get; set; }
        public string Description { get; set; }
    }
}