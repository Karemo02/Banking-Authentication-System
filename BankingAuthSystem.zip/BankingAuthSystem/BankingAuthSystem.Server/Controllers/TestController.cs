﻿using BankingAuthSystem.Server.Services;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace BankingAuthSystem.Server.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TestController : ControllerBase
    {
        private readonly DatabaseService _databaseService;

        public TestController(DatabaseService databaseService)
        {
            _databaseService = databaseService;
        }

        [HttpGet("connection")]
        public async Task<IActionResult> TestConnection()
        {
            var isConnected = await _databaseService.TestConnectionAsync();
            return isConnected ? Ok("Database connected successfully") : StatusCode(500, "Database connection failed");
        }
    }
}