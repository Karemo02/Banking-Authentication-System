﻿using BankingAuthSystem.Server.Models;
using BankingAuthSystem.Server.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using MySql.Data.MySqlClient;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BankingAuthSystem.Server.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly DatabaseService _databaseService;
        private readonly IConfiguration _configuration;

        public AuthController(DatabaseService databaseService, IConfiguration configuration)
        {
            _databaseService = databaseService;
            _configuration = configuration;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] User user)
        {
            // Validate input
            if (user == null || string.IsNullOrWhiteSpace(user.Username) ||
                string.IsNullOrWhiteSpace(user.Password) || string.IsNullOrWhiteSpace(user.Email) ||
                string.IsNullOrWhiteSpace(user.TrustedCountries))
            {
                return BadRequest("All fields are required");
            }

            // Validate username (alphanumeric, 3-50 characters)
            if (!Regex.IsMatch(user.Username, @"^[a-zA-Z0-9]{3,50}$"))
            {
                return BadRequest("Username must be 3-50 alphanumeric characters");
            }

            // Validate email (basic format)
            if (!Regex.IsMatch(user.Email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                return BadRequest("Invalid email format");
            }

            // Validate trusted countries (comma-separated, letters and commas)
            if (!Regex.IsMatch(user.TrustedCountries, @"^[a-zA-Z, ]+$"))
            {
                return BadRequest("Trusted countries must be comma-separated names (e.g., 'UK,USA')");
            }

            // Register user
            var success = await _databaseService.RegisterUserAsync(user);

            if (success)
            {
                return Ok("User registered successfully");
            }
            else
            {
                return BadRequest("Registration failed: Username may already exist");
            }
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.Username) || string.IsNullOrWhiteSpace(request.Password))
            {
                return BadRequest("Username and password are required");
            }

            var (success, username) = await _databaseService.LoginUserAsync(request.Username, request.Password);

            if (!success)
            {
                // Check if account is locked (existing logic for login attempts)
                using var connection = new MySqlConnection(_configuration.GetConnectionString("MySql"));
                await connection.OpenAsync();
                var checkCmd = new MySqlCommand(
                    "SELECT LoginAttempts FROM Users WHERE Username = @Username",
                    connection);
                checkCmd.Parameters.AddWithValue("@Username", request.Username);
                var result = await checkCmd.ExecuteScalarAsync();
                if (result != null && Convert.ToInt32(result) >= 5)
                {
                    return Unauthorized("Account is locked due to too many failed login attempts. Please try again later or contact support.");
                }

                // Check if locked due to IP fraud detection
                var fraudCmd = new MySqlCommand(
                    "SELECT MAX(IsLocked) as IsLocked FROM FraudLog WHERE Username = @Username AND AttemptTime > @TimeThreshold",
                    connection);
                fraudCmd.Parameters.AddWithValue("@Username", request.Username);
                fraudCmd.Parameters.AddWithValue("@TimeThreshold", DateTime.Now.AddMinutes(-15));
                var fraudResult = await fraudCmd.ExecuteScalarAsync();
                bool isIpLocked = fraudResult != null && !DBNull.Value.Equals(fraudResult) && Convert.ToBoolean(fraudResult);
                if (isIpLocked)
                {
                    return Unauthorized("Account locked due to multiple failed login attempts from different IPs. Please contact an admin.");
                }

                return Unauthorized("Invalid username or password");
            }

            // Generate OTP for MFA
            var otp = await _databaseService.GenerateAndStoreOtpAsync(username);
            if (otp == null)
            {
                return StatusCode(500, "Failed to generate OTP");
            }

            return Ok(new { message = "OTP sent to your email (check console for demo)", username });
        }

        [HttpPost("verify-otp")]
        public async Task<IActionResult> VerifyOtp([FromBody] OtpRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.Username) || string.IsNullOrWhiteSpace(request.Otp))
            {
                return BadRequest("Username and OTP are required");
            }

            var isValid = await _databaseService.VerifyOtpAsync(request.Username, request.Otp);
            if (!isValid)
            {
                return Unauthorized("Invalid or expired OTP");
            }

            // Generate JWT token
            var claims = new[]
            {
                new Claim(ClaimTypes.Name, request.Username),
                new Claim(JwtRegisteredClaimNames.Sub, request.Username),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: creds);

            return Ok(new
            {
                token = new JwtSecurityTokenHandler().WriteToken(token),
                expires = token.ValidTo
            });
        }
    }

    public class LoginRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

    public class OtpRequest
    {
        public string Username { get; set; }
        public string Otp { get; set; }
    }
}